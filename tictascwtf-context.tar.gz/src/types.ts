export type Player = 'X' | 'O'
export type BoardState = Array<Player | null>
